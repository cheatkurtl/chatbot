// server.js
const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');

const app = express();
const port = 3000;

app.use(express.json());

app.post('/search', async (req, res) => {
    const query = req.body.query;

    try {
        const response = await axios.get(`https://www.google.com/search?q=${encodeURIComponent(query)}`);
        const $ = cheerio.load(response.data);
        const searchResults = [];

        $('div.g').each((index, element) => {
            const title = $(element).find('h3').text();
            const url = $(element).find('a').attr('href');
            const snippet = $(element).find('span').text();
            searchResults.push({ title, url, snippet });
        });

        // Hier könnte eine Logik implementiert werden, um die Suchergebnisse zu analysieren und eine passende Antwort zu generieren.

        if (searchResults.length > 0) {
            res.json({ success: true, results: searchResults });
        } else {
            res.json({ success: false, message: 'Keine Suchergebnisse gefunden.' });
        }
    } catch (error) {
        console.error('Fehler bei der Suchanfrage:', error);
        res.status(500).json({ success: false, message: 'Interner Serverfehler.' });
    }
});

app.listen(port, () => {
    console.log(`Server läuft auf http://localhost:${port}`);
});
